package com.example.admin.verifyemail;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Main2Activity extends AppCompatActivity {

    TextView email,status,Uid,name;
    Button send,refresh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        email=(TextView)findViewById(R.id.email);
        status=(TextView)findViewById(R.id.status);
        Uid=(TextView)findViewById(R.id.Uid);
        name=(TextView)findViewById(R.id.name);

        send=(Button)findViewById(R.id.send);
        refresh=(Button)findViewById(R.id.refresh);
        setInfo();

        //Set Event
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                send.setEnabled(false);

                FirebaseAuth.getInstance().getCurrentUser()
                        .sendEmailVerification()
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                send.setEnabled(true);

                                if (task.isSuccessful())
                                    Toast.makeText(Main2Activity.this, "Verification email sent to :"+FirebaseAuth.getInstance().getCurrentUser().getEmail(),Toast.LENGTH_SHORT).show();

                                else
                                    Toast.makeText(Main2Activity.this,"Fail to send verification email",Toast.LENGTH_SHORT).show();
                            }
                        });

            }
        });

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().getCurrentUser()
                        .reload()
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                setInfo();
                            }
                        });
            }
        });
    }
    public void setInfo(){
        FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
        if (user!=null)
        {
        email.setText(new StringBuilder("EMAIL:").append(user.getEmail()));
        Uid.setText(new StringBuilder("UID:").append(user.getUid()));
        status.setText(new StringBuilder("STATUS:").append(String.valueOf(user.isEmailVerified())));
         name.setText(new StringBuilder("NAME:").append("hello"+" "+String.valueOf(user.getDisplayName())));
        }
     }
    }

