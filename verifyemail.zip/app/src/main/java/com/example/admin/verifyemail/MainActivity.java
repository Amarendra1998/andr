package com.example.admin.verifyemail;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;

public class MainActivity extends AppCompatActivity {

    private static final int PER_LOGIN = 1000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Start Login
        startActivityForResult(AuthUI.getInstance().createSignInIntentBuilder()
                .setAllowNewEmailAccounts(true).build(),PER_LOGIN);

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode==PER_LOGIN)
        {
            handleSignInResponse(resultCode,data);
            return;
        }
    }
    public void handleSignInResponse(int resultCode,Intent data){
        if (resultCode==RESULT_OK)
        {
            Intent nas = new Intent(MainActivity.this,Main2Activity.class);
            startActivity(nas);
            finish();
            return;
        }
        else
            Toast.makeText(this,"your login is fail",Toast.LENGTH_SHORT).show();
    }
}
